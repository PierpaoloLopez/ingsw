package ProvaLab.Ordinamento;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;

import org.junit.Test;
import org.joda.time.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void Ordinamento()
    {
    	System.out.println("inizio test");
        MyListUtil mylist = new MyListUtil();
        ArrayList<Integer> array = new ArrayList<Integer>();
        ArrayList<Integer> array2= new ArrayList<Integer>();
        array.add(5);
        array.add(10);
        array.add(2);
        array.add(7);
        array.add(11);
        array.add(4);
        mylist.sort(array, 0);
        array2.add(5);
        array2.add(10);
        array2.add(2);
        array2.add(7);
        array2.add(11);
        array2.add(4);
        if (mylist.getOrder()==0) {
        	Collections.sort(array2);
        }
        assertEquals(array2, array);
    }
    
    @Test
    public void ReverseOrdinamento()
    {
    	System.out.println("inizio test2");
        MyListUtil mylist = new MyListUtil();
        ArrayList<Integer> array = new ArrayList<Integer>();
        ArrayList<Integer> array2= new ArrayList<Integer>();
        array.add(5);
        array.add(10);
        array.add(2);
        array.add(7);
        array.add(11);
        array.add(4);
        mylist.sort(array, 1);
        array2.add(5);
        array2.add(10);
        array2.add(2);
        array2.add(7);
        array2.add(11);
        array2.add(4);
        if (mylist.getOrder()==1) {
        	Collections.sort(array2);
        	Collections.reverse(array2);
        }
        assertEquals(array, array2);;
    }
    
}
