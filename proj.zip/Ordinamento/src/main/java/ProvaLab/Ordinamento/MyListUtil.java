package ProvaLab.Ordinamento;

import java.util.Collections;
import java.util.List;

public class MyListUtil {
	private int order;
	
	public List<Integer> sort(List<Integer> list, int order){
		if(order==0) {
			bsort(list);
			setOrder(0);
		}
		else {
			bsort(list);
			Collections.reverse(list);
			setOrder(1);
		}
		return list;  
    }
	public void bsort(List<Integer> list){
		int n= list.size();
		for (int i = 0; i < n-1; i++) {
			for(int j=0; j < n-1; j++) {
				if(list.get(j) > list.get(j+1)) {
					int temp = list.get(j);
					list.set(j, list.get(j+1));
					list.set(j+1, temp);
				}
			}
		}
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
}
